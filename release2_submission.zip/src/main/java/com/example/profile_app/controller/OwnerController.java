package com.example.profile_app.controller;

import com.example.profile_app.entity.Availability;
import com.example.profile_app.entity.Profile;
import com.example.profile_app.repository.ProfileRepository;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/owner")
public class OwnerController {

    private final ProfileRepository profileRepo;

    public OwnerController(ProfileRepository profileRepo) {
        this.profileRepo = profileRepo;
    }

    // Helper: the single source of truth for ownership.
    private Profile getOwnedProfile(Authentication auth) {
        return profileRepo.findByOwnerUsername(auth.getName())
                .orElseThrow(() -> new IllegalStateException("No profile for " + auth.getName()));
    }

    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        Profile profile = getOwnedProfile(auth);
        model.addAttribute("profile", profile);
        return "owner/dashboard";
    }

    @GetMapping("/edit")
    public String editForm(Authentication auth, Model model) {
        Profile profile = getOwnedProfile(auth);
        model.addAttribute("profile", profile);
        model.addAttribute("allSkills", List.of("python", "javascript", "sql", "ux", "testing"));
        model.addAttribute("availabilities", Availability.values());
        return "owner/edit";
    }

    @PostMapping("/edit")
    public String saveEdit(Authentication auth,
                           @RequestParam String headline,
                           @RequestParam String biography,
                           @RequestParam(required = false) List<String> skillIds,
                           @RequestParam String contactEmail,
                           @RequestParam String availability,
                           Model model) {

        Profile profile = getOwnedProfile(auth); // OWNERSHIP CHECK — server side

        // Validation
        if (headline == null || headline.isBlank()) {
            return renderFormWithError(model, profile, "Headline cannot be blank");
        }
        if (contactEmail == null || !contactEmail.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            return renderFormWithError(model, profile, "Contact email is not valid");
        }
        List<String> allowed = List.of("python", "javascript", "sql", "ux", "testing");
        if (skillIds != null) {
            for (String s : skillIds) {
                if (!allowed.contains(s)) {
                    return renderFormWithError(model, profile, "Unknown skill: " + s);
                }
            }
        }
        Availability avail;
        try {
            avail = Availability.fromValue(availability);
        } catch (IllegalArgumentException e) {
            return renderFormWithError(model, profile, "Invalid availability");
        }

        // Save only after validation passes (invalid submissions do not overwrite)
        profile.setHeadline(headline);
        profile.setBiography(biography);
        profile.setSkillIds(skillIds == null ? List.of() : skillIds);
        profile.setContactEmail(contactEmail);
        profile.setAvailability(avail);
        profileRepo.save(profile);

        return "redirect:/owner/dashboard";
    }

    private String renderFormWithError(Model model, Profile profile, String error) {
        model.addAttribute("profile", profile);
        model.addAttribute("allSkills", List.of("python", "javascript", "sql", "ux", "testing"));
        model.addAttribute("availabilities", Availability.values());
        model.addAttribute("error", error);
        return "owner/edit";
    }

    @PostMapping("/publish")
    public String publish(Authentication auth) {
        Profile profile = getOwnedProfile(auth); // OWNERSHIP CHECK
        profile.setPublished(true);
        profileRepo.save(profile);
        return "redirect:/owner/dashboard";
    }

    @PostMapping("/unpublish")
    public String unpublish(Authentication auth) {
        Profile profile = getOwnedProfile(auth); // OWNERSHIP CHECK
        profile.setPublished(false);
        profileRepo.save(profile);
        return "redirect:/owner/dashboard";
    }

    @GetMapping("/preview")
    public String preview(Authentication auth, Model model) {
        Profile profile = getOwnedProfile(auth); // OWNERSHIP CHECK
        model.addAttribute("profile", profile);
        return "owner/preview";
    }
}