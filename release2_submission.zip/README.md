# Profile App

## Accounts (for instructor)
- Owner A (profile p01): username `ownerA`
- Owner B (profile p02): username `ownerB`
- Passwords are supplied privately via the submission channel.

## Run locally
Set these environment variables before running:
- DB_URL
- DB_USERNAME
- DB_PASSWORD
- OWNER_A_PASSWORD
- OWNER_B_PASSWORD

Then run:
.\mvnw.cmd spring-boot:run